package com.demo.admin.demo.Fragments;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.demo.admin.demo.R;


public class States extends AppCompatActivity{

    protected void onCreate(Bundle savedState){
        super.onCreate(savedState);
        setContentView(R.layout.states);
    }
}

